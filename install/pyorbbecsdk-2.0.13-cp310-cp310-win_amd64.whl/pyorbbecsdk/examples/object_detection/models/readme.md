1. Copy the compiled `yolov5s.onnx` file into this directory.
